package edu.many.shoplist.Controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import edu.many.shoplist.Adapters.Adapter;
import edu.many.shoplist.R;

public class MainActivity extends AppCompatActivity {

    private MainActivityManager manager;

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new MainActivityManager();

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        Adapter adapter = new Adapter(manager.getItemLists(),this);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
    }
}
