package edu.many.shoplist.Model;

/**
 * Created by Manel on 20/12/17.
 */
public class ItemList {
    private String name;
    private int cantidad;

    public ItemList(String name, int cantidad) {
        this.cantidad = cantidad;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
