package edu.many.shoplist.Adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import edu.many.shoplist.R;

/**
 * Created by Manel on 20/12/17.
 */
public class Holder extends RecyclerView.ViewHolder{

    TextView textViewName;
    TextView textViewCount;

    public Holder(View itemView) {
        super(itemView);
        textViewCount = (TextView) itemView.findViewById(R.id.textView);
        textViewName = (TextView) itemView.findViewById(R.id.textView2);
    }
}
