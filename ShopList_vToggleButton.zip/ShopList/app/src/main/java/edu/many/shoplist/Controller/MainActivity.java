package edu.many.shoplist.Controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ToggleButton;

import edu.many.shoplist.Adapters.Adapter;
import edu.many.shoplist.R;

public class MainActivity extends AppCompatActivity {

    private MainActivityManager manager;

    private RecyclerView recyclerView;

    private Button btnAdd;

    private ToggleButton tg1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new MainActivityManager();

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        final Adapter adapter = new Adapter(manager.getItemLists(),this);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        tg1 = (ToggleButton) findViewById(R.id.tb1);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tg1.isChecked()) {
                    manager.addItem("nuevos", 1);
                    adapter.notifyDataSetChanged();
                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
    }
}
