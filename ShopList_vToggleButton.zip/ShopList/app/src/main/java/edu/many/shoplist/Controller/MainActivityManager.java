package edu.many.shoplist.Controller;

import java.util.ArrayList;

import edu.many.shoplist.Model.ItemList;

/**
 * Created by Manel on 20/12/17.
 */
public class MainActivityManager {
    private ArrayList<ItemList> itemLists;

    public MainActivityManager() {
        this.itemLists = new ArrayList<>();
        itemLists.add(new ItemList("Arroz",2));
        itemLists.add(new ItemList("Pan",1));
        itemLists.add(new ItemList("Agua",6));
        itemLists.add(new ItemList("Tomate",3));
        itemLists.add(new ItemList("Huevos",12));
        itemLists.add(new ItemList("Sal",1));
    }

    public ArrayList<ItemList> getItemLists() {
        return itemLists;
    }

    public void setItemLists(ArrayList<ItemList> itemLists) {
        this.itemLists = itemLists;
    }

    public void addItem(String name, int cantidad){
        this.itemLists.add(new ItemList(name,cantidad));
    }
}
